# Reference: Struktura HTML prezentace pro HTMLpresenter

Tento soubor je detailní reference struktury. Přečti ho před generováním nové prezentace.

## Jak HTMLpresenter čte prezentaci

1. **Detekce slidů** — presenter hledá slidy podle selektorů v tomto pořadí, vezme první,
   který najde 2+ elementy:
   1. `.reveal .slides > section` (Reveal.js)
   2. `section.slide` ← **toto skill generuje**
   3. `div.slide`
   4. `section[data-slide]`
   5. `body > section` (fallback)

   Skill vždy generuje `<section class="slide">` přímo pod `<body>` — to spadá pod selektor 2.

2. **Párování poznámek** — presenter páruje poznámky se slidy **podle pořadí (indexu od nuly)**.
   První slide v DOM dostane poznámku z klíče `"0"`, druhý z `"1"`, atd. Žádná ID, žádné
   párování přes atributy — čistě pořadí.

3. **Čtení poznámek** — presenter čte poznámky v tomto pořadí priority:
   1. JSON blok `<script type="application/json" id="presenter-notes">` ← **toto skill generuje**
   2. `<aside class="notes">` uvnitř slidu (fallback, skill nepoužívá)
   3. `data-notes` atribut (fallback, skill nepoužívá)

## Proč žádný wrapper

Selektor `body > section` je fallback. Když obalíš slidy do `<div class="deck">`, slidy přestanou
být přímými potomky body. Selektor `section.slide` by je sice našel i tak, ALE wrapper často nese
vlastní CSS (`position: absolute`, `overflow: hidden`, vlastní rozměry), který se pere s tím, jak
presenter zobrazuje aktivní slide fullscreen. Výsledek bývá černá obrazovka. Proto: žádný wrapper.

## Proč žádný navigační JavaScript

Presenter injektuje vlastní CSS a řídí, který slide je viditelný, přes atribut
`data-htmlpresenter-active`. Když má prezentace vlastní JS navigaci (mění class `active`,
poslouchá šipky), dva systémy si konkurují — oba chtějí řídit viditelnost slidů. Proto prezentace
nesmí mít žádnou vlastní navigaci. Jediná logika je v presenteru.

## Default zobrazení slidů

Aby se prezentace dala otevřít i bez presenteru (jako normální stránka, kde je vidět první slide),
použij toto CSS pravidlo:

```css
section.slide:not(:first-child) { display: none; }
```

Když presenter naběhne, přebije tohle vlastním CSS a řídí viditelnost sám. Když presenter neběží,
uvidíš první slide jako titulku. To je správné a žádané chování.

## Kompletní funkční příklad

Tohle je minimální, ale kompletní prezentace, která s presenterem funguje. Slouží jako vzor
struktury — design je záměrně jednoduchý, reálné prezentace mohou být libovolně bohaté.

```html
<!DOCTYPE html>
<html lang="cs">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>AI nástroje pro učitele</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }

    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      background: #0a0a0f;
      color: #ffffff;
    }

    /* POVINNÉ minimum pro presenter */
    section.slide {
      width: 100vw;
      height: 100vh;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      text-align: center;
      padding: 5rem;
    }
    section.slide:not(:first-child) { display: none; }

    /* Design — volné, podle uživatele */
    .eyebrow {
      color: #5eb8ff;
      font-size: 1rem;
      letter-spacing: 0.15em;
      text-transform: uppercase;
      margin-bottom: 2rem;
    }
    h1 { font-size: clamp(3rem, 8vw, 6rem); font-weight: 700; letter-spacing: -0.02em; }
    h2 { font-size: clamp(2rem, 5vw, 4rem); font-weight: 600; }
    p  { font-size: clamp(1.25rem, 2.5vw, 1.75rem); opacity: 0.75; margin-top: 1.5rem; }
    .accent { color: #5eb8ff; }
  </style>
</head>
<body>

  <section class="slide">
    <div class="eyebrow">Workshop · 2026</div>
    <h1>AI nástroje<br>pro učitele</h1>
    <p>Jan Jílek · jilekai.cz</p>
  </section>

  <section class="slide">
    <h2>Problém: <span class="accent">času je málo</span></h2>
    <p>Příprava hodin, opravy, administrativa. AI umí ubrat z každé z těchto oblastí.</p>
  </section>

  <section class="slide">
    <h2>Děkuji.</h2>
    <p>Otázky?</p>
  </section>

  <script type="application/json" id="presenter-notes">
  {
    "0": "Přivítej účastníky. Krátce se představ, řekni proč tě téma baví. Nastav očekávání: 30 minut, dotazy na konci.",
    "1": "Tady zpomal. Zeptej se publika, kolik času týdně tráví přípravou. Nech je chvíli přemýšlet. Pak přejdi ke konkrétním nástrojům.",
    "2": "Poděkuj. Připomeň, kde tě najdou (jilekai.cz). Buď připraven na dotaz ohledně ceny nástrojů a ochrany dat žáků."
  }
  </script>

  <script>
  (function() {
    let i = 0;
    const slides = document.querySelectorAll('section.slide');
    document.addEventListener('keydown', (e) => {
      if (document.body.hasAttribute('data-htmlpresenter-controlled')) return;
      if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
        if (i < slides.length - 1) {
          slides[i].style.display = 'none';
          i++;
          slides[i].style.display = 'flex';
        }
      }
      if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
        if (i > 0) {
          slides[i].style.display = 'none';
          i--;
          slides[i].style.display = 'flex';
        }
      }
    });
  })();
  </script>

</body>
</html>
```

## Časté chyby, kterým se vyhnout

| Chyba | Důsledek | Správně |
|-------|----------|---------|
| `<div class="deck">` kolem slidů | Černá obrazovka | Slidy přímo pod `<body>` |
| Vlastní JS pro šipky bez kontroly `data-htmlpresenter-controlled` | Konflikt s presenterem | Standalone JS dle šablony, vždy s kontrolou atributu |
| Více `<script>` než ty dva povolené (notes + standalone) | Nepředvídatelné chování | Jen JSON poznámky + navigační skript |
| `class="slide active"` | Presenter ztrácí kontrolu | Jen `class="slide"` |
| `<aside class="notes">` ve slidech | Funguje, ale ladění přes AI riskuje rozbití slidu | JSON blok |
| Trailing comma v JSON | Poznámky se nenačtou | Validní JSON |
| Skutečné odřádkování uvnitř JSON stringu | Parse selže | `\n` jako escape sekvence |
| Méně klíčů než slidů | Některé slidy bez poznámek | Klíč pro každý slide |
