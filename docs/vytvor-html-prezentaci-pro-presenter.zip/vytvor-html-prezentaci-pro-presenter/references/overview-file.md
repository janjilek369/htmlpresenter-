# Reference: Přehledový soubor (náhled slidů + poznámky)

Kromě samotné prezentace skill generuje **druhý soubor** — přehled, kde uživatel vidí náhledy
slidů vedle poznámek (Keynote pocit). Slouží k přípravě, ne k prezentování.

## Pravidla přehledu

- **Název souboru:** `{nazev}-prehled.html` (vedle `{nazev}.html`)
- **Read-only.** Přehled se needituje. Když chce uživatel změnit poznámku, řekne AI, ta upraví
  JSON v prezentaci a přehled přegeneruje.
- **Samostatný soubor.** Nepere se s presenterem, není to prezentace. Jen přehled.
- **Náhled slidu = reálný slide** přes `<iframe srcdoc>` — vidíš slide tak, jak vypadá.
- **Design** sladěný s presenterem (glassmorphism, tmavé pozadí, cool blue accent).

## Jak náhled slidu funguje (iframe srcdoc)

Pro každý slide vytvoř samostatný mini-dokument vložený do `<iframe srcdoc="...">`. Mini-dokument
obsahuje styly prezentace + ten jeden slide, přepnutý na `display:flex !important` (aby se zobrazil,
i když je to např. druhý slide, který by jinak byl skrytý přes `:not(:first-child)`).

Iframe se vyrenderuje v plné velikosti (1280×720) a zmenší se přes CSS `transform: scale()` do
karty s poměrem 16:9. `pointer-events:none` a `scrolling="no"` z něj dělají statický náhled.

## Postup generování přehledu

1. Z prezentace vytáhni: `<title>`, obsah `<style>`, všechny `<section class="slide">`, JSON poznámky.
2. Pro každý slide vytvoř kartu: číslo + iframe náhled + poznámka.
3. Slož do přehledové stránky podle šablony níže.
4. Escapuj HTML obsah slidu do `srcdoc` (uvozovky → `&quot;` atd.).

## Šablona přehledu

Nahraď `{TITLE}`, `{SLIDE_COUNT}` a `{CARDS}` (karty pro každý slide). Styly prezentace vlož do
každé srcdoc karty.

```html
<!DOCTYPE html>
<html lang="cs">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>{TITLE} — přehled</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, sans-serif;
      background:
        radial-gradient(ellipse 80% 50% at 20% 0%, rgba(94,184,255,.08), transparent 60%),
        radial-gradient(ellipse 60% 50% at 80% 100%, rgba(180,100,220,.06), transparent 50%),
        #0a0a0f;
      color: rgba(255,255,255,.95);
      min-height: 100vh;
      padding: 48px;
    }
    .head { max-width: 1100px; margin: 0 auto 40px; }
    .head h1 { font-size: 32px; font-weight: 700; letter-spacing: -.02em; }
    .head p { color: rgba(255,255,255,.5); margin-top: 8px; font-size: 15px; }
    .cards { max-width: 1100px; margin: 0 auto; display: flex; flex-direction: column; gap: 20px; }
    .card {
      display: grid;
      grid-template-columns: 64px 360px 1fr;
      gap: 24px;
      align-items: stretch;
      background: rgba(20,20,30,.55);
      backdrop-filter: blur(40px) saturate(180%);
      -webkit-backdrop-filter: blur(40px) saturate(180%);
      border: 1px solid rgba(255,255,255,.08);
      border-radius: 20px;
      padding: 20px;
      box-shadow: 0 8px 32px rgba(0,0,0,.4), inset 0 1px 0 rgba(255,255,255,.06);
    }
    .card__num {
      font-family: 'SF Mono', ui-monospace, monospace;
      font-size: 20px; font-weight: 600;
      color: rgba(94,184,255,.9);
      display: flex; align-items: center; justify-content: center;
    }
    .card__preview {
      aspect-ratio: 16/9;
      border-radius: 12px;
      overflow: hidden;
      border: 1px solid rgba(255,255,255,.08);
      background: #000;
      position: relative;
    }
    /* iframe renderuje ve full size a škáluje se dolů. scale = 360/1280 ≈ 0.281 */
    .card__preview iframe {
      position: absolute; top: 0; left: 0;
      width: 1280px; height: 720px;
      transform: scale(.281);
      transform-origin: top left;
      border: 0;
      pointer-events: none;
    }
    .card__notes { display: flex; flex-direction: column; justify-content: center; }
    .card__notes-label {
      font-size: 11px; font-weight: 600; text-transform: uppercase;
      letter-spacing: .08em; color: rgba(94,184,255,.9); margin-bottom: 10px;
    }
    .card__notes p { font-size: 16px; line-height: 1.6; color: rgba(255,255,255,.85); white-space: pre-wrap; }
    .hint {
      max-width: 1100px; margin: 32px auto 0; padding: 16px 20px;
      background: rgba(20,20,30,.4); border: 1px solid rgba(255,255,255,.06);
      border-radius: 14px; font-size: 13px; color: rgba(255,255,255,.5); line-height: 1.6;
    }
  </style>
</head>
<body>
  <div class="head">
    <h1>{TITLE}</h1>
    <p>Přehled slidů a poznámek · {SLIDE_COUNT} slidů</p>
  </div>
  <div class="cards">
    {CARDS}
  </div>
  <div class="hint">
    Náhled je jen pro čtení. Když chceš upravit poznámku, řekni AI „uprav poznámku ke slidu X" —
    AI přepíše prezentaci a tento přehled přegeneruje. Prezentaci spustíš v Chrome klávesou P.
  </div>
</body>
</html>
```

## Šablona jedné karty

Pro každý slide (index `i` od nuly), kde `{SLIDE_HTML}` je obsah `<section class="slide">…</section>`
a `{STYLE}` jsou styly prezentace:

srcdoc dokument (před escapováním):
```html
<!DOCTYPE html><html><head><meta charset="UTF-8"><style>{STYLE}
section.slide{display:flex!important;width:100vw;height:100vh}</style></head>
<body>{SLIDE_HTML}</body></html>
```

Tento dokument celý HTML-escapuj (`"` → `&quot;`, `<` zůstává uvnitř srcdoc OK, ale uvozovky
musí být escapované) a vlož do `srcdoc`:

```html
<div class="card">
  <div class="card__num">{NUMBER_2_DIGITS}</div>
  <div class="card__preview">
    <iframe srcdoc="{ESCAPED_SRCDOC}" scrolling="no" tabindex="-1"></iframe>
  </div>
  <div class="card__notes">
    <div class="card__notes-label">Poznámky</div>
    <p>{NOTE_TEXT}</p>
  </div>
</div>
```

`{NUMBER_2_DIGITS}` = pořadí slidu od jedničky, dvě číslice (01, 02, …). `{NOTE_TEXT}` =
poznámka z JSON pro tento index (HTML-escapovaná).

## Když nemáš nástroj na escapování

Pokud generuješ ručně (ne v Claude Code s Pythonem), escapuj v srcdoc minimálně dvojité uvozovky
na `&quot;`. Apostrofy a `<`/`>` uvnitř srcdoc obvykle projdou, ale dvojité uvozovky rozbijí
atribut. V Claude Code Desktop použij raději skript (Python `html.escape(doc, quote=True)`).

## Co říct uživateli

Po vygenerování obou souborů:
- `{nazev}.html` — prezentace (otevři v Chrome, stiskni P)
- `{nazev}-prehled.html` — přehled slidů a poznámek pro přípravu (otevři v prohlížeči, jen čtení)

Když uživatel chce změnit poznámku, uprav JSON v prezentaci (Režim B) a **přegeneruj přehled**.
