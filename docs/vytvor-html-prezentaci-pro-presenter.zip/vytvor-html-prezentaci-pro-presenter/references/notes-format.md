# Reference: Formát poznámek a jejich úprava

Tento soubor je reference pro JSON blok poznámek a pro Režim B (úprava poznámek v existující
prezentaci). Přečti ho, když pracuješ s poznámkami.

## Formát JSON bloku

```html
<script type="application/json" id="presenter-notes">
{
  "0": "Poznámky k prvnímu slidu.",
  "1": "Poznámky k druhému slidu.",
  "2": "Poznámky ke třetímu slidu."
}
</script>
```

Pravidla:
- Element je `<script type="application/json" id="presenter-notes">`. `type="application/json"`
  zajistí, že prohlížeč obsah nikdy nezobrazí ani nespustí. `id="presenter-notes"` je přesně to,
  co presenter hledá.
- Umísti blok na konec `<body>`, za poslední slide.
- Klíče jsou indexy slidů od nuly, jako stringy: `"0"`, `"1"`, `"2"`, …
- Hodnoty jsou texty poznámek (stringy).
- Počet klíčů = počet slidů. Každý slide má svůj klíč.

## Validní JSON — na co dát pozor

Presenter čte blok přes `JSON.parse`. Když parse selže, žádné poznámky se nenačtou (spadne to
na fallback nebo prázdno). Proto:

- **Žádné trailing commas** — za posledním párem klíč/hodnota NENÍ čárka.
- **Uvozovky uvnitř textu escapuj** — `"Řekni \"ahoj\" publiku"`.
- **Zalomení řádku uvnitř poznámky** piš jako `\n` — `"První věta.\nDruhá věta na novém řádku."`.
- **Žádné komentáře** — JSON komentáře nepodporuje.

### Špatně

```json
{
  "0": "První slide",
  "1": "Druhý slide",   ← trailing comma za posledním → parse selže
}
```

### Správně

```json
{
  "0": "První slide",
  "1": "Druhý slide"
}
```

## Jak psát obsah poznámek

Poznámky vidí jen mluvčí v presenter okně. Nejsou součástí slidu.

Dobrá poznámka:
- 2–5 vět
- Říká, CO udělat, ne co je na slidu ("zpomal", "zeptej se publika", "pauza", "přejdi k příkladu")
- Doplňuje slide, neduplikuje ho
- V jazyce prezentace

Příklady dobrých poznámek:
- `"Začni příběhem o tom, jak jsi poprvé zkusil AI na opravování testů. Osobní, krátké. Pak teprve čísla."`
- `"Nejdůležitější slide. Zdůrazni, že data žáků nepatří do veřejných nástrojů. Pauza po té větě."`
- `"Rychle přejdi, je to jen přechod. Naváž otázkou na další slide."`

## Režim B: Úprava poznámek v existující prezentaci

Když uživatel chce upravit, přepsat nebo přidat poznámky:

### Klíčové pravidlo

**Sahej JEN do JSON bloku `<script type="application/json" id="presenter-notes">`. Slidů se
NEDOTÝKEJ.** To je celý smysl odděleného bloku — poznámky lze ladit, aniž by hrozilo rozbití
slidů. Když budeš editovat i slidy, porušíš základní princip.

### Postup

1. Najdi v souboru blok `<script type="application/json" id="presenter-notes">`.
2. Přečti aktuální JSON.
3. Uprav hodnoty podle zadání uživatele.
4. Ověř, že JSON zůstal validní (klíče, escapování, žádné trailing commas, počet klíčů = počet slidů).
5. Vrať výsledek.

### Číslování slidů — pozor na nedorozumění

Uživatel typicky myslí slidy lidsky od jedničky ("slide 3" = třetí slide), ale JSON klíče jsou
od nuly ("2" = třetí slide). Když uživatel řekne "uprav poznámku ke slidu 3":

- Nejčastěji myslí **třetí slide v pořadí**, což je klíč `"2"`.
- Když si nejsi jistý, krátce potvrď: "Třetí slide v pořadí (titulní = první), upravuji index 2 — ano?"

### Co vrátit

- **V Claude Code Desktop:** uprav přímo soubor (edit JSON bloku), nebo vrať celý soubor.
- **V chatu:** můžeš vrátit jen upravený JSON blok, pokud je to pro uživatele praktičtější, nebo
  celý soubor, když ho chce stáhnout. Zeptej se / přizpůsob situaci.

### Přidání poznámek do prezentace, která je nemá

Když prezentace nemá JSON blok vůbec:
1. Spočítej slidy (`<section class="slide">`).
2. Vytvoř `<script type="application/json" id="presenter-notes">` s klíčem pro každý slide.
3. Vlož ho na konec `<body>`, za poslední slide.
4. Slidů se nedotýkej.
