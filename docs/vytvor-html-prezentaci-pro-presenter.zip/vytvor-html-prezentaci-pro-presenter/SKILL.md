---
name: vytvor-html-prezentaci-pro-presenter
description: >
  Generate single-file HTML presentations compatible with the HTMLpresenter Chrome extension,
  and edit speaker notes inside existing ones. Use this skill whenever the user wants to:
  create an HTML presentation that will be presented with HTMLpresenter, build slides for a
  webinar / talk / workshop as an HTML file, generate a presentation from their notes or an
  outline, or edit / rewrite / add speaker notes in an existing HTMLpresenter file. Trigger on
  phrases like: "vytvoř HTML prezentaci pro presenter", "prezentace pro presenter", "udělej
  prezentaci pro webinář", "html prezentace se skillem", "prezentace na téma ...", "uprav
  poznámku ke slidu", "přepiš poznámky", "přidej poznámky k prezentaci", or any request to
  produce or modify a presentation meant to be opened with the HTMLpresenter extension. The
  skill only enforces the structure HTMLpresenter needs (slide markup + notes block); design,
  slide count, theme and content are fully up to the user.
---

# HTML prezentace pro HTMLpresenter

Tento skill generuje HTML prezentace, které fungují s Chrome extension **HTMLpresenter**, a
edituje poznámky v už hotových prezentacích. Skill řeší **jen mechaniku**, kterou presenter
potřebuje (struktura slidů + blok poznámek). Design, počet slidů, téma, barvy a obsah jsou
plně na uživateli.

Při tvorbě nové prezentace skill generuje **dva soubory**:
1. `{nazev}.html` — samotná prezentace (otevře se v Chrome, prezentuje se klávesou P)
2. `{nazev}-prehled.html` — přehled slidů a poznámek pro přípravu (náhledy slidů vedle poznámek,
   Keynote pocit, jen pro čtení)

## Důležité: co skill vynucuje a co ne

**Skill VYNUCUJE (jinak presenter nefunguje):**
1. Slidy jsou `<section class="slide">` přímo pod `<body>` — žádný wrapper container
2. Žádný vlastní JavaScript, který by si konkuroval s presenterem (kromě povoleného standalone navigačního JS — viz sekce "Standalone navigace")
3. Poznámky jsou v odděleném JSON bloku `<script type="application/json" id="presenter-notes">`

**Skill PŘIDÁVÁ POVINNĚ (pro standalone procházení):**
- Krátký navigační JS, který umožní procházení prezentace šipkami i bez spuštěného presenteru. Tento JS se sám vypne, když presenter převezme kontrolu (detekuje atribut `data-htmlpresenter-controlled` na `<body>`).

**Skill NEVYNUCUJE (volné, podle uživatele):**
- Počet slidů
- Design, barvy, fonty, layout
- Téma a obsah
- Tmavé/světlé pozadí
- Obrázky, grafy, animace uvnitř slidů

Analogie: skill je norma na zásuvku. Určuje, jak musí vypadat kolíky, aby to pasovalo do
presenteru. Jaký spotřebič si zapojíš, je na tobě.

## Dva režimy

Tento skill má dva režimy. Pozná se z toho, co uživatel chce.

### Režim A: Vytvoření nové prezentace

Uživatel chce novou prezentaci ("vytvoř prezentaci na téma X", "udělej slidy pro webinář").

### Režim B: Úprava poznámek v existující prezentaci

Uživatel má hotovou prezentaci a chce upravit poznámky ("uprav poznámku ke slidu 3",
"přepiš poznámky", "přidej poznámky"). V tomto režimu **sahej JEN do JSON bloku poznámek,
NIKDY do slidů.** To je celý smysl odděleného bloku — poznámky lze ladit bez rizika rozbití
slidů.

## Než začneš generovat (Režim A)

Pokud uživatel rovnou předhodí poznámky nebo osnovu, pracuj s tím. Pokud je zadání vágní,
zeptej se na to podstatné — ne víc než je potřeba:

- **Téma a cíl** — o čem prezentace je, k čemu slouží (webinář, přednáška, školení)
- **Obsah** — má uživatel vlastní body / osnovu / poznámky, nebo má skill obsah navrhnout?
- **Počet slidů** — má představu, nebo necháme na obsahu?
- **Design** — má preferenci (tmavé/světlé, barva, vibe), nebo necháme na skillu?
- **Poznámky** — má je dodat, nebo je má skill napsat podle obsahu slidů?

Nepřehlcuj uživatele otázkami. Když je něco zřejmé z kontextu, použij to.

## Závazná struktura výstupu (Režim A)

Generuj **dva soubory**: prezentaci a přehled. Před napsáním si přečti `references/structure.md`
pro přesnou referenci struktury prezentace, `references/notes-format.md` pro formát poznámek a
`references/overview-file.md` pro generování přehledového souboru.

Nejdřív vytvoř prezentaci (`{nazev}.html`), pak z ní vygeneruj přehled (`{nazev}-prehled.html`).

Kostra:

```html
<!DOCTYPE html>
<html lang="cs">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Název prezentace</title>
  <style>
    /* Veškerý CSS inline. Design podle uživatele. */
    /* POVINNÉ minimum pro presenter: */
    section.slide { width: 100vw; height: 100vh; box-sizing: border-box; }
    section.slide:not(:first-child) { display: none; }
  </style>
</head>
<body>

  <section class="slide">
    <!-- obsah prvního slidu -->
  </section>

  <section class="slide">
    <!-- obsah druhého slidu -->
  </section>

  <!-- další slidy... -->

  <!-- POZNÁMKY: oddělený blok, presenter ho čte přes JSON.parse -->
  <script type="application/json" id="presenter-notes">
  {
    "0": "Poznámky k prvnímu slidu. Co říct, kde dát pauzu, co zdůraznit.",
    "1": "Poznámky k druhému slidu.",
    "2": "Poznámky ke třetímu slidu."
  }
  </script>

  <!-- STANDALONE NAVIGACE: umožňuje procházení šipkami i bez presenteru.
       Když presenter běží, nastaví na <body> atribut data-htmlpresenter-controlled
       a tento skript se sám vypne (presenter převezme řízení). -->
  <script>
  (function() {
    let i = 0;
    const slides = document.querySelectorAll('section.slide');
    document.addEventListener('keydown', (e) => {
      if (document.body.hasAttribute('data-htmlpresenter-controlled')) return;
      if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
        if (i < slides.length - 1) {
          slides[i].style.display = 'none';
          i++;
          slides[i].style.display = 'flex';
        }
      }
      if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
        if (i > 0) {
          slides[i].style.display = 'none';
          i--;
          slides[i].style.display = 'flex';
        }
      }
    });
  })();
  </script>

</body>
</html>
```

## Pravidla, která NESMÍŠ porušit (Režim A)

1. **Žádný wrapper kolem slidů.** Slidy jsou přímými potomky `<body>`. NE `<div class="deck">`,
   NE `<main>`, NE žádný container. Presenter hledá slidy přímo pod body.

2. **Pouze povolený JavaScript.** V prezentaci smí být pouze dva `<script>` bloky:
   - JSON poznámky (`<script type="application/json" id="presenter-notes">`)
   - Standalone navigační JS (přesně dle šablony výše — žádné jiné variace, žádné rozšíření)
   
   Žádný další JS — žádné transitions, fragments, automatické přehrávání, vlastní šipky 
   navíc, ani žádná class `active`. Standalone JS používá pouze `style.display`, nemění 
   class slidů.

3. **Žádná class `active` ani vlastní stav.** Žádné `class="slide active"`. Default zobrazení
   řeší CSS pravidlo `section.slide:not(:first-child) { display: none; }`. Standalone JS
   mění viditelnost přes `style.display`. Presenter pak přebírá řízení přes vlastní data atributy.

4. **Poznámky JEN v JSON bloku.** Negeneruj `<aside class="notes">` uvnitř slidů. Poznámky
   patří výhradně do JSON bloku. (Presenter umí `<aside>` jako fallback, ale skill ho nepoužívá —
   chceme čisté oddělení.)

5. **Klíče v JSON = index slidu od nuly jako string.** První slide = `"0"`, druhý = `"1"`, atd.
   Počet klíčů musí přesně odpovídat počtu slidů. Každý slide má poznámku (i kdyby krátkou).

6. **Validní JSON.** Žádné trailing commas, správně escapované uvozovky a zalomení řádků
   (`\n` pro nový řádek uvnitř poznámky, NIKDY skutečný nový řádek). Když parse selže, 
   presenter poznámky nenačte.

7. **Standalone navigační JS dodržuj přesně.** Skript musí na začátku každého keydown 
   handleru zkontrolovat `data-htmlpresenter-controlled` atribut a vrátit se. Bez této 
   kontroly by se v presenter modu pral s extension o řízení slidů.

## Jak psát dobré poznámky

Poznámky jsou pro mluvčího, vidí je jen on v presenter okně. Nejsou to titulky slidu.

**FORMÁT — vždy dodržuj:**

- **Bodový seznam, ne souvislý text.** Každý bod začíná `•` a končí `\n` (escape sekvence v JSON, ne skutečný nový řádek).
- **Krátké body** — maximálně jedna věta, ideálně 5–10 slov.
- **Tučně zvýrazni klíčová slova** přes `<b>` tagy. V každém bodě 1–2 tučná slova, která mluvčí vidí periferním viděním.
- **3–6 bodů na slide** — méně = mluvčí nedostane podporu, víc = zahltí ho.

**OBSAH — co psát:**

- Konkrétní akce: "zpomal", "pauza", "zeptej se publika", "ukázka naživo"
- Klíčové fráze, které mluvčí chce říct přesně
- Emocionální tipy: "tady přidej vlastní příběh", "buď tichý 3 sekundy"
- Přechody: "naváži otázkou na další slide"
- Připravená čísla / data, která mluvčí nesmí zapomenout

**NEDĚLEJ:**

- Dlouhé souvislé věty (mluvčí to nestihne přečíst)
- Opakování textu slidu (k ničemu)
- Generické "vysvětli to dobře" (nicneříkající)

**Příklady správně:**

```json
"0": "• <b>Přivítej</b> publikum, krátký osobní hook\n• Nastav očekávání: <b>20 minut</b>\n• Dotazy nech <b>na konec</b>"
```

```json
"1": "• <b>Nejdůležitější slide</b> — zpomal\n• Ukázka přes <b>screen share</b>\n• Pauza po větě o ceně"
```

**Špatně (souvislé věty):**

```json
"0": "Přivítejte publikum a krátce se představte. Nastavte očekávání pro tuto prezentaci, která bude trvat 20 minut. Dotazy nechte na konec."
```

Tohle mluvčí nepřečte při prezentaci. Bodové poznámky ano.

**Jazyk** — piš v jazyce prezentace (typicky čeština).

## Standalone navigace (jak funguje, proč je tam)

Prezentace musí jít proklikat i bez spuštěného presenteru — uživatel ji může otevřít 
v Chrome, na mobilu, poslat klientovi jako self-contained HTML. Proto skill vždy generuje 
malý `<script>` na konci `<body>`, který přidá šipkové ovládání.

**Klíčový princip:** Tento JS se sám vypne, když presenter běží. Extension při startu 
presenter modu přidá na `<body>` atribut `data-htmlpresenter-controlled`. Skript to v 
keydown handleru detekuje a vrátí se bez akce. Když uživatel ukončí presenter (Esc), 
extension atribut odebere — skript se zase aktivuje.

Skript NIKDY neměň. Generuj přesně podle šablony výše. Žádné rozšíření (klik na slide, 
swipe, indikátory), pokud o to uživatel explicitně neřekne.

## Úprava poznámek (Režim B)

Když uživatel chce upravit poznámky v existující prezentaci:

1. **Najdi JSON blok** `<script type="application/json" id="presenter-notes">` v souboru.
2. **Uprav JEN hodnoty v tomto bloku.** Slidů se NEDOTÝKEJ.
3. Zachovej validní JSON (klíče, escapování, žádné trailing commas).
4. Když uživatel říká "slide 3", mysli na to, jestli myslí lidsky třetí slide (index "2")
   nebo index 3. V nejistotě se zeptej, nebo to potvrď ("třetí slide v pořadí, tedy index 2").
5. Vrať celý upravený soubor, nebo jen upravený JSON blok — podle toho, co je pro uživatele
   praktičtější (u Claude Code Desktop celý soubor / edit, v chatu může stačit blok).
6. **Přegeneruj přehled** (`{nazev}-prehled.html`), pokud existuje — poznámky se v něm musí
   aktualizovat. Viz `references/overview-file.md`.

## Jak prezentaci použít (řekni uživateli)

Po vygenerování stručně připomeň workflow:
1. Ulož HTML soubor
2. Otevři ho v Google Chrome
3. Stiskni **P** → otevře se presenter okno s poznámkami + audience okno (fullscreen) pro sdílení
4. Šipky nebo pravé tlačítko myši = další slide

## Jazyk

- Komunikace s uživatelem: čeština
- Obsah prezentace a poznámky: jazyk, který si uživatel přeje (typicky čeština)
- HTML, CSS, kód: standardně anglické názvy tříd a struktury
- `lang` atribut v `<html>` nastav podle jazyka obsahu

## Kontrola před odevzdáním

- Jsou slidy přímými potomky `<body>` bez wrapperu?
- Žádná class `active` ani vlastní stav na slidech?
- Je JSON blok poznámek validní (žádné trailing commas, `\n` místo skutečných odřádkování)?
- Má stejný počet klíčů jako slidů? Má každý slide poznámku?
- Je tam standalone navigační skript přesně dle šablony?
- Otevře se soubor v prohlížeči i bez presenteru jako normální stránka a šipky procházejí slidy?
- Vygeneroval jsi i přehledový soubor `{nazev}-prehled.html`?
- Sedí v přehledu počet karet s počtem slidů a poznámky s indexy?
